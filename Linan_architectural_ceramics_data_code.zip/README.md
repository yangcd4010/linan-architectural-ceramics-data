# Lin’an architectural ceramics: supporting data and code

Companion data for “Component-associated compositional variation in architectural ceramics from the Southern Song imperial city of Lin’an, China”.

The principal comparison is between ornamental roof elements S6/S7/S18 and roof-covering tiles S8/S10/S12/S15. S5 is a separate roof component included in the specified sensitivity comparisons. The package contains XRF results for 11 mapped fragments, 20 original XRD scans, five original FTIR spectra and instrument plots, and the 12 original SEM fields used in Figure 6.

## Files and manuscript links

| Files under `data/` | Contents and use |
| --- | --- |
| `Table3_complete_oxide_values.csv`; `Table_S3_complete_XRF_11_fragments.csv` | Ten major oxides, LOI and complete XRF report transcription for 11 fragments; report-to-specimen mapping. |
| `Table_S6A_specimen_ratios.csv`; `Table_S6B_group_comparisons.csv` | Specimen ratios and 14 comparison scenarios, including memberships, geometric means and percentage contrasts; Figure 5a–b and Table S6. |
| `PCA_8oxide_*`; `PCA_10oxide_*`; `Table_S6C_PCA_specifications.csv` | Inputs, CLR-centered matrices, scores, loadings and explained variances for Figures 5c–d and S4, plus alternative specifications. |
| `XRD_raw/`; `XRD_raw_file_index.csv` | Twenty original two-column instrument exports; specimen mapping and hashes. Columns: 2-theta in degrees, original intensity. |
| `XRD_reprocessed_arrays.npz`; `XRD_processed_normalized_patterns.csv` | Processed data on each original scan grid and on the shared interpolated grid. |
| `XRD_consensus_peaks.csv` | Cross-specimen peak groups supporting Figure 4b and the mineral-reflection summary. |
| `XRD_angle_masks.csv`; `XRD_correlation_A.csv` through `D.csv`; `Table_S4_XRD_sensitivity_summary.csv`; `XRD_pairwise_changes_relative_to_B.csv` | Correlations and strong-reflection exclusion comparisons; Figure S3 and Table S4. A is the shared full range; B is 5–65 degrees; C/D apply the stored exclusion masks. |
| `Table_S7_peak_thresholds.csv`; `XRD_peak_threshold_membership.csv` | Nine threshold settings and all 180 specimen/setting detection outcomes. |
| `XRD_raw_processed_low_angle.csv`; `hematite_candidate_peak_review.csv` | Low-angle raw/processed values and candidate hematite peak measurements; Figures S5/S7. |
| `FTIR_raw/`; `FTIR_sample_mapping.csv` | Five CSV spectra and their five original instrument-plot PDFs. Instrument files 1–5 map to S1/S2/S3/S4/S17. Each CSV has 7,468 rows without a header: wavenumber (cm⁻¹), transmittance (%). Figure S6 and Table S8. |
| `SEM_raw/`; `SEM_figure6_mapping.csv` | Twelve unchanged original JPEG fields and the panel-to-specimen mapping for Figure 6. Scale bars and acquisition annotations remain in the images. |
| `Table_S2_cross_method_evidence_expanded.csv` | Specimen descriptions, recorded labels, analytical coverage and observations; Table S2. |
| `literature_comparison_sources.csv`; `literature_relief_tiles.csv`; `Anhui_Table2_original_elemental_values.csv` | Source locations, reporting bases and the limited published values used for comparison. Citations and DOIs identify the original studies. |

## Measurement and calculation conventions

XRF values are reported dry-basis mass percentages. `sum_10_oxides` excludes LOI. S12 LOI is 0.089%. Unreported entries are retained as such, rather than set to zero. The complete transcription preserves the report label `Pr3O11`; its chemical identity is unresolved, as stated in Table S3. This entry is outside both PCA oxide subsets and the two-ratio analysis.

In the comparison CSVs, `decorative` identifies ornamental roof elements and `roof` identifies the roof-covering comparison set; the explicit specimen lists define each sensitivity scenario. Group geometric means are calculated from mean log ratios, and percentage contrasts are 100 × (group A geometric mean / group B geometric mean − 1). The hypothetical S5/S6 parent scenario treats their mean log ratio as one unit alongside S7 and S18. The `*_closed10` columns are ten-oxide-closed descriptive values; reported-value ratios are unchanged by that common closure factor.

PCA uses natural-log CLR transformation, column centering and SVD without variable standardization. LOI is excluded. XRD uses AsLS baseline correction (lambda 2 × 10⁶, p = 0.01, 12 iterations), an 11-point third-order Savitzky–Golay filter, and normalization to the maximum in 5–65 degrees. The baseline detects paired low-angle peaks in six fragments; five retain the pair in all nine threshold settings. FTIR CSVs retain the original transmittance values.

## Numerical reproduction

Tested environment: Python 3.12.14, NumPy 2.5.3 and SciPy 1.18.1.

Extract the ZIP into a folder. From that folder, which contains this README and the `data/` and `scripts/` directories, run:

```text
python -m pip install -r scripts/requirements.txt
python scripts/verify_numeric_bundle.py
```

The program reproduces the 14 ratio comparisons, verifies the eight- and ten-oxide centered matrices and explained variances, repeats processing of all 20 XRD scans, checks the 180 threshold outcomes, and verifies the FTIR source-file hashes. It prints results as JSON without changing the inputs. This is a numerical and file-integrity check; measurement uncertainty is discussed in the manuscript. Final figure files are supplied separately with the article.

## Sources and citation

The XRF transcription and specimen mapping derive from the study records. XRD TXT files, FTIR CSV/PDF exports and SEM JPEGs are retained unchanged. Archaeological descriptions and source labels are represented in Table S2 and the article’s supplementary information. Literature files contain comparison data and source citations; elemental mass percentages and bulk oxide mass percentages remain on their original reporting bases.

When using these materials, cite the accompanying article and the original publications identified in the literature tables where applicable.

## License

The data and code are shared under the Creative Commons Attribution 4.0 International (CC BY 4.0) license. Cite the authors and applicable original literature sources when reusing this material.

License text: https://creativecommons.org/licenses/by/4.0/legalcode

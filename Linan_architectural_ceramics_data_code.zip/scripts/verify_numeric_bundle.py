"""Verify reported contrasts, PCA inputs and original XRD processing from this bundle.

Run: python scripts/verify_numeric_bundle.py
Requires numpy and scipy. No input file is modified. Results print as JSON.
These checks verify calculation/transcription, not instrument accuracy.
"""
from pathlib import Path
from hashlib import sha256
import csv,json
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import spsolve
from scipy.signal import savgol_filter,find_peaks
OUT=Path(__file__).resolve().parent.parent;DATA=OUT/'data'
def read(name):
    with (DATA/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
xrf={r['sample']:r for r in read('Table3_complete_oxide_values.csv')}
comparisons=[]
for row in read('Table_S6B_group_comparisons.csv'):
    a=row['decorative_ids'].split(';');b=row['roof_ids'].split(';')
    result={'specification':row['specification']}
    for den,key in [('SiO2','Fe_Si'),('Al2O3','Fe_Al')]:
        logratio=lambda s:np.log(float(xrf[s]['Fe2O3'])/float(xrf[s][den]))
        if 'hypothetical parent' in row['specification']:
            la=np.mean([np.mean([logratio('S5'),logratio('S6')]),logratio('S7'),logratio('S18')])
        else:la=np.mean([logratio(s) for s in a])
        lb=np.mean([logratio(s) for s in b]);pct=float(100*np.expm1(la-lb))
        assert abs(pct-float(row[key+'_difference_percent']))<1e-10
        result[key+'_difference_percent']=pct
    comparisons.append(result)
assert len(comparisons)==14 and xrf['S12']['LOI']=='0.089'
pca={}
for n in [8,10]:
    rows=read(f'PCA_{n}oxide_input.csv');cols=list(rows[0])[1:]
    x=np.array([[float(r[c]) for c in cols] for r in rows]);assert np.all(x>0)
    logs=np.log(x);clr=logs-logs.mean(1,keepdims=True);centered=clr-clr.mean(0,keepdims=True)
    stored=read(f'PCA_{n}oxide_CLR_centered.csv')
    np.testing.assert_allclose(centered,[[float(r[c]) for c in cols] for r in stored],rtol=0,atol=1e-12)
    s=np.linalg.svd(centered,full_matrices=False)[1];pct=100*s*s/(s*s).sum()
    np.testing.assert_allclose(pct,[float(r['variance_pct']) for r in read(f'PCA_{n}oxide_variance.csv')],rtol=0,atol=1e-10)
    pca[str(n)]=pct[:2].tolist()
z=np.load(DATA/'XRD_reprocessed_arrays.npz');maxdiff=0
for r in read('XRD_raw_file_index.csv'):
    path=DATA/r['file'];assert sha256(path.read_bytes()).hexdigest()==r['sha256']
    x,y=np.loadtxt(path).T;s=r['sample'];assert np.array_equal(x,z[s+'_theta']) and np.all(np.diff(x)>0)
    n=len(y);d=sparse.diags([np.ones(n-2),-2*np.ones(n-2),np.ones(n-2)],[0,1,2],shape=(n-2,n),format='csc')
    penalty=2e6*(d.T@d);w=np.ones(n)
    for _ in range(12):
        base=spsolve(sparse.spdiags(w,0,n,n)+penalty,w*y);w=.01*(y>base)+.99*(y<=base)
    corr=np.clip(savgol_filter(np.clip(y-base,0,None),11,3,mode='interp'),0,None)
    norm=corr/corr[(x>=5)&(x<=65)].max()*100
    delta=float(abs(norm-z[s+'_norm']).max());maxdiff=max(maxdiff,delta);assert delta<1e-10,(s,delta)
for row in read('XRD_peak_threshold_membership.csv'):
    s=row['sample'];x=z[s+'_theta'];y=z[s+'_norm']
    peaks,_=find_peaks(y,height=float(row['height']),prominence=float(row['prominence']),distance=max(2,round(.12/np.median(np.diff(x)))))
    a=bool(np.any(abs(x[peaks]-8.85)<=.16));b=bool(np.any(abs(x[peaks]-17.70)<=.16))
    assert a==(row['peak8_85']=='True') and b==(row['peak17_70']=='True') and (a and b)==(row['paired']=='True')
for row in read('FTIR_sample_mapping.csv'):
    for name,hashcol in [('raw_csv','csv_sha256'),('original_plot','pdf_sha256')]:
        assert sha256((DATA/row[name]).read_bytes()).hexdigest()==row[hashcol]
print(json.dumps(dict(status='PASS',component_comparisons=comparisons,PCA_PC1_PC2_percent=pca,
    raw_XRD_scans=20,maximum_XRD_processed_difference=maxdiff,threshold_specimen_rows=180,
    FTIR_original_curves=5,S12_LOI=0.089,scope='Computational and file-integrity checks; not validation of instrument accuracy'),indent=2))
